﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="CustomerEditForm.aspx.cs" company="">
//   
// </copyright>
// <summary>
//   The customer edit form.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System.Linq;

namespace EDMs.Web.Controls.Document
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Web.Hosting;
    using System.Web.UI;
    using System.Web.UI.WebControls;

    using EDMs.Business.Services.Document;
    using EDMs.Data.Entities;
    using EDMs.Web.Utilities.Sessions;

    using Telerik.Web.UI;

    /// <summary>
    /// The customer edit form.
    /// </summary>
    public partial class AttachDocList : Page
    {

        /// <summary>
        /// The folder service.
        /// </summary>
        private readonly DQREDocumentService _dqreDocumentService;

        private readonly DQREDocumentAttachFileService attachFileService;


        /// <summary>
        /// Initializes a new instance of the <see cref="DocumentInfoEditForm"/> class.
        /// </summary>
        public AttachDocList()
        {
            this._dqreDocumentService = new  DQREDocumentService();
            this.attachFileService = new   DQREDocumentAttachFileService();
         
        }

        /// <summary>
        /// The page_ load.
        /// </summary>
        /// <param name="sender">
        /// The sender.
        /// </param>
        /// <param name="e">
        /// The e.
        /// </param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                this.lblUserId.Value = UserSession.Current.User.Id.ToString();
            }
        }


        protected void grdDocument_OnNeedDataSource(object sender, GridNeedDataSourceEventArgs e)
        {
            if (!string.IsNullOrEmpty(Request.QueryString["docId"]))
            {
                Guid docId;
                Guid.TryParse(this.Request.QueryString["docId"].ToString(), out docId);
               
                var attachList = this.attachFileService.GetAllDocId(docId).Where(t => t.TypeId == 1 && t.Extension.ToLower() == ".pdf");
                this.grdDocument.DataSource = attachList;
            }
            else
            {
                this.grdDocument.DataSource = new List<DQRETransmittalAttachFileService>();
            }
        }

        protected void ajaxDocument_AjaxRequest(object sender, AjaxRequestEventArgs e)
        {
        }
    }
}